/**
=========================================================
* Shikshana MUI - v3.0.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-material-ui
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/
import React, { useEffect, useState } from 'react';

// Shikshana MUI components
import ArgonBox from "components/ArgonBox";
import ArgonButton from "components/ArgonButton";
import Table from 'react-bootstrap/Table';
import Icon from "@mui/material/Icon";
import ArgonTypography from "components/ArgonTypography";
import ArgonInput from "components/ArgonInput";

// Authentication layout components
import IllustrationLayout from "layouts/authentication/components/IllustrationLayout1";

import axios from "axios";
import { ipofserver } from 'global';

// Image
const bgImage =
  "https://raw.githubusercontent.com/creativetimofficial/public-assets/master/argon-dashboard-pro/assets/img/signin-ill.jpg";

function Illustration() {

  const [hospitals, setHospitals] = useState([]);

  useEffect(() => {
    axios.get(`${ipofserver}getAllStud/${localStorage.getItem('AdminLoginUserstd')}`)
      // .then(res => res.json())
      .then(data => {
        // alert(data.data)
        setHospitals(data.data);
      })
      .catch(err => {
        console.log(err);
      })
  }, [])

  const submitButton = async() => {
    const finallst = [];
    hospitals.map(async (inputid) => {
      const value = document.getElementById("file" + inputid[0]).files[0];
      if (value != undefined) {
        finallst.push(value)
      }
      else {
        finallst.push(undefined)
      }
    })    
    // console.log(finallst);
    var bool = true
    finallst.map((ele) => {
      if (ele == undefined) {
        bool = false
      }
    })
    if (!bool) {
      alert("Please check file!")
    }
    else {
      finallst.map(async (inputid,index) => {
        const formData = new FormData();
        formData.append('File', inputid); 
        formData.append('userid', hospitals[index][0]);  
        formData.append('usermail', hospitals[index][1]); 
        formData.append('userstd', hospitals[index][5]); 
        const res = await axios.post(`${ipofserver}uploadGradeCard`, formData);
      })  
      alert("All report cards uploaded!")
      window.location.href = '/reportCard'
    }
  }

  return (
    <IllustrationLayout
      title="Report card"
      description="Upload all student report cards"
      illustration={{
        image: bgImage,
        title: '"Attention is the new currency"',
        description:
          "The more effortless the writing looks, the more effort the writer actually put into the process.",
      }}
    >
      <ArgonBox component="form" role="form">
        <Table striped bordered hover>
          <thead style={{ fontSize: 18 }}>
            <tr>
              <th>Student Id</th>
              <th>Student details</th>
              <th>Standard</th>
              <th>
                Select grade card
              </th>
            </tr>
          </thead>
          <tbody style={{ fontSize: 16 }}>
            {hospitals.map((hospital, index) => (
              <tr key={index}>
                <td>{hospital[0]}</td>
                <td>
                  <p style={{ marginBottom: '1px' }}><strong>{hospital[2]}</strong></p>
                  <p>{hospital[3]}</p>
                </td>
                <td>{hospital[5]}</td>
                <td>
                  <input type="file" size="large" id={'file' + hospital[0]} accept="image/*" />
                </td>
              </tr>
            ))}
          </tbody>
        </Table>

        <ArgonBox mt={4} mb={5}>
          <ArgonButton color="info" size="large" onClick={submitButton} fullWidth>
            Submit
          </ArgonButton>
        </ArgonBox>
      </ArgonBox>
    </IllustrationLayout>
  );
}

export default Illustration;
