/**
=========================================================
* Shikshana MUI - v3.0.0
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-material-ui
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/
import React, { useEffect, useState } from 'react';

// Shikshana MUI components
import ArgonBox from "components/ArgonBox";
import ArgonButton from "components/ArgonButton";
import Table from 'react-bootstrap/Table';
import Icon from "@mui/material/Icon";
import ArgonTypography from "components/ArgonTypography";
import ArgonInput from "components/ArgonInput";

// Authentication layout components
import IllustrationLayout from "layouts/authentication/components/IllustrationLayout1";

import axios from "axios";
import { ipofserver } from 'global';

// Image
const bgImage =
  "https://raw.githubusercontent.com/creativetimofficial/public-assets/master/argon-dashboard-pro/assets/img/signin-ill.jpg";

function Illustration() {

  const [hospitals, setHospitals] = useState([]);

  useEffect(() => {
    axios.get(`${ipofserver}getAllStud/${localStorage.getItem('AdminLoginUserstd')}`)
      // .then(res => res.json())
      .then(data => {
        // alert(data.data)
        setHospitals(data.data);
      })
      .catch(err => {
        console.log(err);
      })
  }, [])

  function submitButton(userid) {
    axios.post(ipofserver + 'verifyUser', {
      userid: userid,
      typeofuser: "User"
    })
      .then(function (response) {
        if (response.data == "success") {
          alert("User verified successfully !")
          window.location.href = '/verifyStudent'
        }
        else {
          alert("Something wrong !")
        }
      })
      .catch(function (error) {
        return error;
      });
  }

  return (
    <IllustrationLayout
      title="Verify Student"
      description="Verify all student if genuine."
      illustration={{
        image: bgImage,
        title: '"Attention is the new currency"',
        description:
          "The more effortless the writing looks, the more effort the writer actually put into the process.",
      }}
    >
      <ArgonBox component="form" role="form">
        <Table striped bordered hover>
          <thead style={{ fontSize: 18 }}>
            <tr>
              <th>Student Id</th>
              <th>Student details</th>
              <th>Standard</th>
              <th>
                Verify
              </th>
            </tr>
          </thead>
          <tbody style={{ fontSize: 16 }}>
            {hospitals.map((hospital, index) => (
              <tr key={index}>
                <td>{hospital[0]}</td>
                <td>
                  <p style={{ marginBottom: '1px' }}><strong>{hospital[2]}</strong></p>
                  <p>{hospital[3]}</p>
                </td>
                <td>{hospital[5]}</td>
                <td>
                  {hospital[8] == "Verified" ? (
                    <ArgonBox mr={1} style={{ color: 'Green', fontWeight: 'bold' }}>
                      Verified
                    </ArgonBox>
                  ) : (
                    <ArgonButton color="info" size="large" onClick={() => submitButton(hospital[0])} fullWidth>
                      Verify
                    </ArgonButton>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </ArgonBox>
    </IllustrationLayout>
  );
}

export default Illustration;
